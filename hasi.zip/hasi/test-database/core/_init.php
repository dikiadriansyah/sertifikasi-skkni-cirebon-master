<?php
//Call other file
require_once '_config.php';
require_once '_other.php';
require_once '_crud.php';
?>